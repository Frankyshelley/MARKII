import os, time, sys
import subprcess
for platform import system
